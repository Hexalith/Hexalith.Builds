// <copyright file="WorkspaceCommandModeTests.cs" company="ITANEO">
// Copyright (c) ITANEO (https://www.itaneo.com). All rights reserved.
// Licensed under the MIT license. See LICENSE file in the project root for full license information.
// </copyright>

namespace Hexalith.Builds.ModuleTool.Tests.Workspace;

using Hexalith.Builds.ModuleTool.Cli;
using Hexalith.Builds.Tooling.Diagnostics;
using Hexalith.Builds.Tooling.Manifest;
using Hexalith.Builds.Tooling.Runtime;
using Hexalith.Builds.Tooling.Workspace;

using Shouldly;

using Xunit;

/// <summary>Verifies the public mode option belongs only to run and test.</summary>
public sealed class WorkspaceCommandModeTests
{
    /// <summary>Allows process-backed success fixtures to start; short readiness deadlines have separate controls.</summary>
    private static readonly TimeSpan _successfulStartupTimeout = TimeSpan.FromSeconds(30);

    /// <summary>Verifies the public command carries its resolved mode and hash into the engine-written plan.</summary>
    /// <param name="command">The public command.</param>
    /// <param name="mode">The requested mode.</param>
    /// <returns>A task for the assertion.</returns>
    [Theory]
    [InlineData("run", "source")]
    [InlineData("run", "package")]
    [InlineData("test", "source")]
    [InlineData("test", "package")]
    [InlineData("run", null)]
    [InlineData("test", null)]
    public async Task PublicCommandWritesResolvedMappingIntoEnginePlanAsync(string command, string? mode)
    {
        using WorkspaceGitFixture fixture = await WorkspaceGitFixture.CreateAsync().ConfigureAwait(true);
        (string Aspire, string Docker, string DaprHome, string NativeDotnet)? portable = OperatingSystem.IsWindows()
            ? await CompositionTestFiles.BuildPortableToolchainAsync(fixture.Directory, TestContext.Current.CancellationToken).ConfigureAwait(true)
            : null;
        string repository = CompositionTestFiles.RepositoryRoot();
        CopyFixtureTree(Path.Combine(repository, "artifacts", "g4-fixture", "bin"), Path.Combine(fixture.Checkout, "artifacts", "g4-fixture", "bin"), skipBuildFolders: false);
        CopyFixtureTree(Path.Combine(repository, "test", "fixtures", "module", "executable"), Path.Combine(fixture.Checkout, "test", "fixtures", "module", "executable"), skipBuildFolders: true);
        string manifest = Path.Combine(fixture.Checkout, "test", "fixtures", "module", "executable", "hexalith.module-manifest.v1.json");
        string fakeAppHost = await CompositionTestFiles.BuildFakeAppHostAsync(fixture.Directory, "capture", TestContext.Current.CancellationToken).ConfigureAwait(true);
        CompositionEngineOptions options = new(fakeAppHost, typeof(ModuleCommandApplication).Assembly.Location)
        {
            AspireCommand = portable?.Aspire ?? CompositionTestFiles.CreateAspire(fixture.Directory),
            DockerCommand = portable?.Docker ?? CompositionTestFiles.CreateStubDocker(fixture.Directory),
            DaprHome = portable?.DaprHome ?? CompositionTestFiles.CreateDaprHome(fixture.Directory, CompositionToolchainPins.DaprCliVersion, CompositionToolchainPins.DaprRuntimeVersion),
            StateDirectory = Path.Combine(fixture.Directory, "state"),
            WorkspaceRoot = Path.Combine(fixture.Directory, "workspaces"),
            ReadinessTimeout = TimeSpan.FromSeconds(5),
        };

#pragma warning disable CA2007 // Test assertions require the xUnit synchronization context.
        await using StringWriter output = new();
        await using StringWriter error = new();
#pragma warning restore CA2007
        List<string> arguments = [command, "--manifest", manifest];
        if (command == "test")
        {
            arguments.AddRange(["--profile", "full"]);
        }

        if (mode is not null)
        {
            arguments.AddRange(["--mode", mode]);
        }

        arguments.AddRange(["--output", "json"]);
        _ = await ModuleCommandApplication.InvokeAsync(
            [.. arguments],
            output,
            error,
            TestContext.Current.CancellationToken,
            typeof(ModuleCommandApplication).Assembly.Location,
            options).ConfigureAwait(true);

        string capturedPlan = Path.Combine(fixture.Directory, "fake-apphost", "out", "captured-plan.json");
        File.Exists(capturedPlan).ShouldBeTrue(output.ToString());
        using System.Text.Json.JsonDocument plan = System.Text.Json.JsonDocument.Parse(await File.ReadAllTextAsync(capturedPlan, TestContext.Current.CancellationToken).ConfigureAwait(true));
        System.Text.Json.JsonElement sourceMapping = plan.RootElement.GetProperty("sourceMapping");
        System.Text.Json.JsonElement identity = plan.RootElement.GetProperty("platformIdentity");
        identity.GetProperty("commit").GetString().ShouldBe(sourceMapping.GetProperty("platformIdentity").GetProperty("commit").GetString());
        identity.GetProperty("catalogCommit").GetString().ShouldNotBeNullOrWhiteSpace();
        identity.GetProperty("releaseTag").GetString().ShouldBe("v1.0.0");
        sourceMapping.GetProperty("mode").GetString().ShouldBe(mode ?? "source");
        sourceMapping.GetProperty("entries").GetArrayLength().ShouldBe(4);
        sourceMapping.GetProperty("entries").EnumerateArray().Single(entry => entry.GetProperty("identity").GetString() == "Hexalith.Dep")
            .GetProperty("origin").GetString().ShouldBe(mode ?? "source");
        string hash = plan.RootElement.GetProperty("sourceMappingHash").GetString()!;
        string mapping = await File.ReadAllTextAsync(Path.Combine(fixture.Directory, "fake-apphost", "out", "captured-mapping.json"), TestContext.Current.CancellationToken).ConfigureAwait(true);
        mapping.ShouldContain(hash);
        (await File.ReadAllTextAsync(Path.Combine(fixture.Directory, "fake-apphost", "out", "captured-mapping-hash.txt"), TestContext.Current.CancellationToken).ConfigureAwait(true)).ShouldBe(hash);
    }

    /// <summary>Verifies the public command persists the active-only mapping in a non-Git workspace.</summary>
    /// <param name="mode">The selected mode.</param>
    /// <returns>A task for the assertion.</returns>
    [Theory]
    [InlineData("source")]
    [InlineData("package")]
    public async Task PublicNoGitRunWritesActiveOnlyPlanAsync(string mode)
    {
        using WorkspaceGitFixture fixture = await WorkspaceGitFixture.CreateAsync().ConfigureAwait(true);
        string active = Path.Combine(fixture.Directory, "no-git");
        _ = Directory.CreateDirectory(active);
        await File.WriteAllTextAsync(Path.Combine(active, "Hexalith.Builds.slnx"), "<Solution />", TestContext.Current.CancellationToken).ConfigureAwait(true);
        string repository = CompositionTestFiles.RepositoryRoot();
        CopyFixtureTree(Path.Combine(repository, "artifacts", "g4-fixture", "bin"), Path.Combine(active, "artifacts", "g4-fixture", "bin"), skipBuildFolders: false);
        CopyFixtureTree(Path.Combine(repository, "test", "fixtures", "module", "executable"), Path.Combine(active, "test", "fixtures", "module", "executable"), skipBuildFolders: true);
        string manifest = Path.Combine(active, "test", "fixtures", "module", "executable", "hexalith.module-manifest.v1.json");
        string fakeAppHost = await CompositionTestFiles.BuildFakeAppHostAsync(fixture.Directory, "capture", TestContext.Current.CancellationToken).ConfigureAwait(true);
        (string Aspire, string Docker, string DaprHome, string NativeDotnet)? portable = OperatingSystem.IsWindows()
            ? await CompositionTestFiles.BuildPortableToolchainAsync(fixture.Directory, TestContext.Current.CancellationToken).ConfigureAwait(true)
            : null;
        CompositionEngineOptions options = new(fakeAppHost, typeof(ModuleCommandApplication).Assembly.Location)
        {
            AspireCommand = portable?.Aspire ?? CompositionTestFiles.CreateAspire(fixture.Directory),
            DockerCommand = portable?.Docker ?? CompositionTestFiles.CreateStubDocker(fixture.Directory),
            DaprHome = portable?.DaprHome ?? CompositionTestFiles.CreateDaprHome(fixture.Directory, CompositionToolchainPins.DaprCliVersion, CompositionToolchainPins.DaprRuntimeVersion),
            StateDirectory = Path.Combine(fixture.Directory, "state"),
            WorkspaceRoot = Path.Combine(fixture.Directory, "workspaces"),
            ReadinessTimeout = TimeSpan.FromSeconds(5),
        };

#pragma warning disable CA2007 // Test assertions require the xUnit synchronization context.
        await using StringWriter output = new();
        await using StringWriter error = new();
#pragma warning restore CA2007
        _ = await ModuleCommandApplication.InvokeAsync(
            ["run", "--manifest", manifest, "--mode", mode, "--output", "json"],
            output,
            error,
            TestContext.Current.CancellationToken,
            typeof(ModuleCommandApplication).Assembly.Location,
            options).ConfigureAwait(true);

        string capturedPlan = Path.Combine(fixture.Directory, "fake-apphost", "out", "captured-plan.json");
        if (mode == "package")
        {
            output.ToString().ShouldContain("HXW007");
            File.Exists(capturedPlan).ShouldBeFalse();
            Directory.Exists(options.StateDirectory).ShouldBeFalse();
            Directory.Exists(options.WorkspaceRoot).ShouldBeFalse();
            return;
        }

        output.ToString().ShouldContain("HXW007");
        File.Exists(capturedPlan).ShouldBeTrue(output.ToString());
        using System.Text.Json.JsonDocument plan = System.Text.Json.JsonDocument.Parse(await File.ReadAllTextAsync(capturedPlan, TestContext.Current.CancellationToken).ConfigureAwait(true));
        System.Text.Json.JsonElement mapping = plan.RootElement.GetProperty("sourceMapping");
        mapping.GetProperty("mode").GetString().ShouldBe(mode);
        mapping.GetProperty("hasGit").GetBoolean().ShouldBeFalse();
        mapping.GetProperty("entries").GetArrayLength().ShouldBe(1);
        mapping.GetProperty("entries")[0].GetProperty("origin").GetString().ShouldBe("source");
        (await File.ReadAllTextAsync(Path.Combine(fixture.Directory, "fake-apphost", "out", "captured-mapping-hash.txt"), TestContext.Current.CancellationToken).ConfigureAwait(true))
            .ShouldBe(plan.RootElement.GetProperty("sourceMappingHash").GetString());
    }

    /// <summary>Verifies each identity mismatch is reported at the public command boundary.</summary>
    /// <param name="mismatch">The mismatch to create.</param>
    /// <param name="format">The requested output format.</param>
    /// <returns>A task for the assertion.</returns>
    [Theory]
    [InlineData("composition", "human")]
    [InlineData("composition", "json")]
    [InlineData("catalog", "human")]
    [InlineData("catalog", "json")]
    [InlineData("tool", "human")]
    [InlineData("tool", "json")]
    public async Task PublicPackageIdentityMismatchRendersBeforeDescriptorsAsync(string mismatch, string format)
    {
        using WorkspaceGitFixture fixture = await WorkspaceGitFixture.CreateAsync(
            withDirectManifest: true,
            toolVersionRange: mismatch == "tool" ? "[9999.0.0,)" : null).ConfigureAwait(true);
        string manifest = Path.Combine(fixture.Checkout, "references", "Hexalith.Dep", "module.json");
        _ = await WorkspaceRootResolver.ResolveAsync(manifest, WorkspaceMode.Source, TestContext.Current.CancellationToken).ConfigureAwait(true);
        if (mismatch == "composition")
        {
            string platform = Path.Combine(fixture.Checkout, "references", "Hexalith.Platform");
            await File.WriteAllTextAsync(Path.Combine(platform, "next.txt"), "next", TestContext.Current.CancellationToken).ConfigureAwait(true);
            _ = await WorkspaceGitFixture.RunGitAsync(platform, "add", "next.txt").ConfigureAwait(true);
            _ = await WorkspaceGitFixture.RunGitAsync(platform, "-c", "user.name=Workspace Test", "-c", "user.email=workspace@example.invalid", "commit", "-m", "next Platform").ConfigureAwait(true);
            _ = await WorkspaceGitFixture.RunGitAsync(fixture.Checkout, "add", "references/Hexalith.Platform").ConfigureAwait(true);
        }
        else if (mismatch == "catalog")
        {
            await File.WriteAllTextAsync(Path.Combine(fixture.Checkout, "references", "Hexalith.Builds", "dirty.txt"), "dirty", TestContext.Current.CancellationToken).ConfigureAwait(true);
        }

        CompositionEngineOptions options = new(Path.Combine(fixture.Directory, "missing-apphost.dll"), typeof(ModuleCommandApplication).Assembly.Location)
        {
            StateDirectory = Path.Combine(fixture.Directory, "state"),
            WorkspaceRoot = Path.Combine(fixture.Directory, "workspaces"),
        };
#pragma warning disable CA2007 // Test assertions require the xUnit synchronization context.
        await using StringWriter output = new();
        await using StringWriter error = new();
#pragma warning restore CA2007
        int exitCode = await ModuleCommandApplication.InvokeAsync(
            ["run", "--manifest", manifest, "--mode", "package", "--output", format],
            output,
            error,
            TestContext.Current.CancellationToken,
            typeof(ModuleCommandApplication).Assembly.Location,
            options).ConfigureAwait(true);

        string rule = mismatch switch { "composition" => "HXW008", "catalog" => "HXW009", _ => "HXW010" };
        exitCode.ShouldBe((int)ToolExitCode.PrerequisiteUnavailable, output.ToString());
        string rendered = output.ToString();
        switch (mismatch)
        {
            case "composition":
                rendered.ShouldContain("composition gitlink");
                rendered.ShouldContain("committed identity");
                break;
            case "catalog":
                rendered.ShouldContain("dirty");
                rendered.ShouldContain("pins");
                rendered.ShouldContain("references/Hexalith.Builds");
                break;
            default:
                rendered.ShouldContain("Tool version");
                rendered.ShouldContain("[9999.0.0,)");
                rendered.ShouldContain("hexalith-platform.json");
                break;
        }

        if (format == "human")
        {
            rendered.ShouldContain(rule + " Prerequisite PrerequisiteUnavailable");
        }
        else
        {
            using System.Text.Json.JsonDocument response = System.Text.Json.JsonDocument.Parse(rendered);
            System.Text.Json.JsonElement diagnostic = response.RootElement.GetProperty("diagnostics").EnumerateArray()
                .Single(item => item.GetProperty("ruleId").GetString() == rule);
            diagnostic.GetProperty("phase").GetString().ShouldBe("Prerequisite");
            diagnostic.GetProperty("category").GetString().ShouldBe("PrerequisiteUnavailable");
        }

        Directory.Exists(options.StateDirectory).ShouldBeFalse();
        Directory.Exists(options.WorkspaceRoot).ShouldBeFalse();
    }

    /// <summary>Verifies source identity warnings remain visible when the public test command passes.</summary>
    /// <param name="format">The public diagnostic format.</param>
    /// <returns>A task for the assertion.</returns>
    [Theory]
    [InlineData("human")]
    [InlineData("json")]
    public async Task PublicSourceWarningAppearsOnSuccessAsync(string format)
    {
        using WorkspaceGitFixture fixture = await WorkspaceGitFixture.CreateAsync().ConfigureAwait(true);
        string manifest = await PrepareDirtyPlatformExecutableAsync(fixture).ConfigureAwait(true);
        string fakeAppHost = await CompositionTestFiles.BuildFakeAppHostAsync(fixture.Directory, "ready", TestContext.Current.CancellationToken).ConfigureAwait(true);
        (string aspire, string docker, string daprHome, string nativeDotnet) = await CompositionTestFiles.BuildPortableToolchainAsync(fixture.Directory, TestContext.Current.CancellationToken).ConfigureAwait(true);
        CompositionEngineOptions options = new(fakeAppHost, typeof(ModuleCommandApplication).Assembly.Location)
        {
            AspireCommand = aspire,
            DockerCommand = docker,
            DaprHome = daprHome,
            NativeDotnetCommand = nativeDotnet,
            ProfileExecutorOverride = (_, _, _) => Task.FromResult(new ToolCommandResult("completed", ToolOutcome.Passed(), [])),
            StateDirectory = Path.Combine(fixture.Directory, "state"),
            WorkspaceRoot = Path.Combine(fixture.Directory, "workspaces"),
            ReadinessTimeout = _successfulStartupTimeout,
        };

#pragma warning disable CA2007 // Test assertions require the xUnit synchronization context.
        await using StringWriter output = new();
        await using StringWriter error = new();
#pragma warning restore CA2007
        int exitCode = await ModuleCommandApplication.InvokeAsync(
            ["test", "--manifest", manifest, "--profile", "full", "--mode", "source", "--output", format],
            output,
            error,
            TestContext.Current.CancellationToken,
            typeof(ModuleCommandApplication).Assembly.Location,
            options).ConfigureAwait(true);

        exitCode.ShouldBe((int)ToolExitCode.Success, output.ToString());
        AssertPublicIdentityWarning(output.ToString(), format, "HXW011");
    }

    /// <summary>Verifies source identity warnings remain visible when the public run command later fails.</summary>
    /// <param name="format">The public diagnostic format.</param>
    /// <returns>A task for the assertion.</returns>
    [Theory]
    [InlineData("human")]
    [InlineData("json")]
    public async Task PublicSourceWarningAppearsOnFailureAsync(string format)
    {
        using WorkspaceGitFixture fixture = await WorkspaceGitFixture.CreateAsync().ConfigureAwait(true);
        string manifest = await PrepareDirtyPlatformExecutableAsync(fixture).ConfigureAwait(true);
        CompositionEngineOptions options = new(Path.Combine(fixture.Directory, "missing-apphost.dll"), typeof(ModuleCommandApplication).Assembly.Location)
        {
            AspireCommand = CompositionTestFiles.CreateAspire(fixture.Directory),
            DaprHome = Path.Combine(fixture.Directory, "missing-dapr-home"),
            DockerCommand = CompositionTestFiles.CreateStubDocker(fixture.Directory),
            StateDirectory = Path.Combine(fixture.Directory, "state"),
            WorkspaceRoot = Path.Combine(fixture.Directory, "workspaces"),
        };

#pragma warning disable CA2007 // Test assertions require the xUnit synchronization context.
        await using StringWriter output = new();
        await using StringWriter error = new();
#pragma warning restore CA2007
        int exitCode = await ModuleCommandApplication.InvokeAsync(
            ["run", "--manifest", manifest, "--mode", "source", "--output", format],
            output,
            error,
            TestContext.Current.CancellationToken,
            typeof(ModuleCommandApplication).Assembly.Location,
            options).ConfigureAwait(true);

        exitCode.ShouldBe((int)ToolExitCode.PrerequisiteUnavailable, output.ToString());
        AssertPublicIdentityWarning(output.ToString(), format, "HXW011");
        output.ToString().ShouldContain("HXR011");
    }

    /// <summary>Verifies one public package refusal renders all observable identity conditions in both formats.</summary>
    /// <param name="format">The public diagnostic format.</param>
    /// <returns>A task for the assertion.</returns>
    [Theory]
    [InlineData("human")]
    [InlineData("json")]
    public async Task PublicPackageRefusalReportsSeveralIdentityConditionsAsync(string format)
    {
        using WorkspaceGitFixture fixture = await WorkspaceGitFixture.CreateAsync().ConfigureAwait(true);
        string manifest = await PrepareDirtyPlatformExecutableAsync(fixture).ConfigureAwait(true);
        string platform = Path.Combine(fixture.Checkout, "references", "Hexalith.Platform");
        string builds = Path.Combine(fixture.Checkout, "references", "Hexalith.Builds");
        _ = await WorkspaceGitFixture.RunGitAsync(platform, "tag", "-d", "v1.0.0").ConfigureAwait(true);
        await File.WriteAllTextAsync(Path.Combine(builds, "dirty.txt"), "dirty", TestContext.Current.CancellationToken).ConfigureAwait(true);
        CompositionEngineOptions options = new(Path.Combine(fixture.Directory, "missing-apphost.dll"), typeof(ModuleCommandApplication).Assembly.Location)
        {
            AspireCommand = CompositionTestFiles.CreateAspire(fixture.Directory),
            StateDirectory = Path.Combine(fixture.Directory, "state"),
            WorkspaceRoot = Path.Combine(fixture.Directory, "workspaces"),
        };

#pragma warning disable CA2007 // Test assertions require the xUnit synchronization context.
        await using StringWriter output = new();
        await using StringWriter error = new();
#pragma warning restore CA2007
        int exitCode = await ModuleCommandApplication.InvokeAsync(
            ["run", "--manifest", manifest, "--mode", "package", "--output", format],
            output,
            error,
            TestContext.Current.CancellationToken,
            typeof(ModuleCommandApplication).Assembly.Location,
            options).ConfigureAwait(true);

        exitCode.ShouldBe((int)ToolExitCode.PrerequisiteUnavailable, output.ToString());
        output.ToString().ShouldContain("HXW009");
        output.ToString().ShouldContain("HXW011");
        if (format == "json")
        {
            using System.Text.Json.JsonDocument response = System.Text.Json.JsonDocument.Parse(output.ToString());
            response.RootElement.GetProperty("diagnostics").EnumerateArray().Count().ShouldBeGreaterThanOrEqualTo(2);
        }

        Directory.Exists(options.WorkspaceRoot).ShouldBeFalse();
    }

    /// <summary>Verifies catalog refusal precedes descriptors and removes its private run workspace.</summary>
    /// <param name="format">The public diagnostic format.</param>
    /// <returns>A task for the assertion.</returns>
    [Theory]
    [InlineData("human")]
    [InlineData("json")]
    public async Task PublicCatalogFailureRetainsHxw009BeforeDescriptorsAsync(string format)
    {
        using WorkspaceGitFixture fixture = await WorkspaceGitFixture.CreateAsync(malformedCatalog: true).ConfigureAwait(true);
        string repository = CompositionTestFiles.RepositoryRoot();
        CopyFixtureTree(Path.Combine(repository, "artifacts", "g4-fixture", "bin"), Path.Combine(fixture.Checkout, "artifacts", "g4-fixture", "bin"), skipBuildFolders: false);
        CopyFixtureTree(Path.Combine(repository, "test", "fixtures", "module", "executable"), Path.Combine(fixture.Checkout, "test", "fixtures", "module", "executable"), skipBuildFolders: true);
        string manifest = Path.Combine(fixture.Checkout, "test", "fixtures", "module", "executable", "hexalith.module-manifest.v1.json");

        // Any descriptor load, by the command or the engine, would report HXD001 for this child.
        string missingChild = Path.Combine(fixture.Directory, "missing-descriptor-child.dll");
        CompositionEngineOptions options = new(typeof(ModuleCommandApplication).Assembly.Location, missingChild)
        {
            AspireCommand = CompositionTestFiles.CreateAspire(fixture.Directory),
            DockerCommand = CompositionTestFiles.CreateStubDocker(fixture.Directory),
            DaprHome = CompositionTestFiles.CreateDaprHome(fixture.Directory, CompositionToolchainPins.DaprCliVersion, CompositionToolchainPins.DaprRuntimeVersion),
            StateDirectory = Path.Combine(fixture.Directory, "state"),
            WorkspaceRoot = Path.Combine(fixture.Directory, "workspaces"),
        };

#pragma warning disable CA2007 // Test assertions require the xUnit synchronization context.
        await using StringWriter output = new();
        await using StringWriter error = new();
#pragma warning restore CA2007
        int exitCode = await ModuleCommandApplication.InvokeAsync(
            ["run", "--manifest", manifest, "--mode", "package", "--output", format],
            output,
            error,
            TestContext.Current.CancellationToken,
            missingChild,
            options).ConfigureAwait(true);

        exitCode.ShouldBe((int)ToolExitCode.PrerequisiteUnavailable, output.ToString());
        output.ToString().ShouldContain("HXW009");
        output.ToString().ShouldNotContain("HXR020");
        output.ToString().ShouldNotContain("HXD");
        Directory.Exists(options.StateDirectory).ShouldBeFalse();
        if (Directory.Exists(options.WorkspaceRoot))
        {
            Directory.GetDirectories(options.WorkspaceRoot).ShouldBeEmpty();
        }
    }

    /// <summary>Verifies missing and unmapped primary native test paths fail before composition starts.</summary>
    /// <param name="outsideMapping">Whether the native project exists in a package-origin root.</param>
    /// <returns>A task for the assertion.</returns>
    [Theory]
    [InlineData(false)]
    [InlineData(true)]
    public async Task PublicTestReportsPrimaryNativePathBeforeCompositionAsync(bool outsideMapping)
    {
        using WorkspaceGitFixture fixture = await WorkspaceGitFixture.CreateAsync().ConfigureAwait(true);
        string repository = CompositionTestFiles.RepositoryRoot();
        CopyFixtureTree(Path.Combine(repository, "artifacts", "g4-fixture", "bin"), Path.Combine(fixture.Checkout, "artifacts", "g4-fixture", "bin"), skipBuildFolders: false);
        CopyFixtureTree(Path.Combine(repository, "test", "fixtures", "module", "executable"), Path.Combine(fixture.Checkout, "test", "fixtures", "module", "executable"), skipBuildFolders: true);
        string manifest = Path.Combine(fixture.Checkout, "test", "fixtures", "module", "executable", "hexalith.module-manifest.v1.json");
        string profile = Path.Combine(fixture.Checkout, "test", "fixtures", "module", "executable", "profiles", "p0-two-module-full.fixture.json");
        string contents = await File.ReadAllTextAsync(profile, TestContext.Current.CancellationToken).ConfigureAwait(true);
        const string nativeProject = "references/Hexalith.Dep/Native.csproj";
        if (outsideMapping)
        {
            string path = Path.Combine(fixture.Checkout, "references", "Hexalith.Dep", "Native.csproj");
            _ = Directory.CreateDirectory(Path.GetDirectoryName(path)!);
            await File.WriteAllTextAsync(path, "<Project Sdk=\"Microsoft.NET.Sdk\" />", TestContext.Current.CancellationToken).ConfigureAwait(true);
        }

        string updated = outsideMapping
            ? contents.Replace("test/fixtures/module/executable/P0Fixture.NativeTests.VsTest/P0Fixture.NativeTests.VsTest.csproj", nativeProject, StringComparison.Ordinal)
            : contents.Replace("P0Fixture.NativeTests.VsTest.csproj", "missing.csproj", StringComparison.Ordinal);
        await File.WriteAllTextAsync(profile, updated, TestContext.Current.CancellationToken).ConfigureAwait(true);
        string fakeAppHost = await CompositionTestFiles.BuildFakeAppHostAsync(fixture.Directory, "capture", TestContext.Current.CancellationToken).ConfigureAwait(true);
        (string Aspire, string Docker, string DaprHome, string NativeDotnet)? portable = OperatingSystem.IsWindows()
            ? await CompositionTestFiles.BuildPortableToolchainAsync(fixture.Directory, TestContext.Current.CancellationToken).ConfigureAwait(true)
            : null;
        CompositionEngineOptions options = new(fakeAppHost, typeof(ModuleCommandApplication).Assembly.Location)
        {
            AspireCommand = portable?.Aspire ?? CompositionTestFiles.CreateAspire(fixture.Directory),
            DockerCommand = portable?.Docker ?? CompositionTestFiles.CreateStubDocker(fixture.Directory),
            DaprHome = portable?.DaprHome ?? CompositionTestFiles.CreateDaprHome(fixture.Directory, CompositionToolchainPins.DaprCliVersion, CompositionToolchainPins.DaprRuntimeVersion),
            StateDirectory = Path.Combine(fixture.Directory, "state"),
            WorkspaceRoot = Path.Combine(fixture.Directory, "workspaces"),
        };

#pragma warning disable CA2007 // Test assertions require the xUnit synchronization context.
        await using StringWriter output = new();
        await using StringWriter error = new();
#pragma warning restore CA2007
        int exitCode = await ModuleCommandApplication.InvokeAsync(
            ["test", "--manifest", manifest, "--profile", "full", "--mode", "package", "--output", "json"],
            output,
            error,
            TestContext.Current.CancellationToken,
            typeof(ModuleCommandApplication).Assembly.Location,
            options).ConfigureAwait(true);

        exitCode.ShouldBe((int)(outsideMapping ? ToolExitCode.TopologyOrLifecycle : ToolExitCode.UsageOrManifest));
        output.ToString().ShouldContain(outsideMapping ? "HXW006" : "HXM005");
        output.ToString().ShouldContain(outsideMapping ? nativeProject : "profile.nativeTests.project");
        Directory.Exists(options.WorkspaceRoot).ShouldBeFalse();
    }

    /// <summary>Verifies public test mode carries its resolved hash into the spawned native test process.</summary>
    /// <param name="mode">The selected mode.</param>
    /// <param name="profile">The selected native test platform.</param>
    /// <returns>A task for the assertion.</returns>
    [Theory]
    [InlineData("source", "full")]
    [InlineData("package", "full")]
    [InlineData("source", "full-mtp")]
    [InlineData("package", "full-mtp")]
    public async Task PublicTestCarriesResolvedHashIntoNativeProcessAsync(string mode, string profile)
    {
        using WorkspaceGitFixture fixture = await WorkspaceGitFixture.CreateAsync().ConfigureAwait(true);
        string repository = CompositionTestFiles.RepositoryRoot();
        CopyFixtureTree(Path.Combine(repository, "artifacts", "g4-fixture", "bin"), Path.Combine(fixture.Checkout, "artifacts", "g4-fixture", "bin"), skipBuildFolders: false);
        CopyFixtureTree(Path.Combine(repository, "test", "fixtures", "module", "executable"), Path.Combine(fixture.Checkout, "test", "fixtures", "module", "executable"), skipBuildFolders: true);
        string manifest = Path.Combine(fixture.Checkout, "test", "fixtures", "module", "executable", "hexalith.module-manifest.v1.json");
        string fakeAppHost = await CompositionTestFiles.BuildFakeAppHostAsync(fixture.Directory, "ready", TestContext.Current.CancellationToken).ConfigureAwait(true);
        (string aspire, string docker, string daprHome, string nativeDotnet) = await CompositionTestFiles.BuildPortableToolchainAsync(fixture.Directory, TestContext.Current.CancellationToken).ConfigureAwait(true);
        CompositionEngineOptions options = new(fakeAppHost, typeof(ModuleCommandApplication).Assembly.Location)
        {
            AspireCommand = aspire,
            DockerCommand = docker,
            DaprHome = daprHome,
            NativeDotnetCommand = nativeDotnet,
            ProfileExecutorOverride = (_, _, _) => Task.FromResult(new ToolCommandResult("completed", ToolOutcome.Passed(), [])),
            StateDirectory = Path.Combine(fixture.Directory, "state"),
            WorkspaceRoot = Path.Combine(fixture.Directory, "workspaces"),
            ReadinessTimeout = _successfulStartupTimeout,
        };

#pragma warning disable CA2007 // Test assertions require the xUnit synchronization context.
        await using StringWriter output = new();
        await using StringWriter error = new();
#pragma warning restore CA2007
        _ = await ModuleCommandApplication.InvokeAsync(
            ["test", "--manifest", manifest, "--profile", profile, "--mode", mode, "--output", "json"],
            output,
            error,
            TestContext.Current.CancellationToken,
            typeof(ModuleCommandApplication).Assembly.Location,
            options).ConfigureAwait(true);

        string planFile = Path.Combine(fixture.Directory, "fake-apphost", "out", "captured-plan.json");
        File.Exists(planFile).ShouldBeTrue(output.ToString());
        using System.Text.Json.JsonDocument plan = System.Text.Json.JsonDocument.Parse(await File.ReadAllTextAsync(planFile, TestContext.Current.CancellationToken).ConfigureAwait(true));
        string hash = plan.RootElement.GetProperty("sourceMappingHash").GetString()!;
        plan.RootElement.GetProperty("sourceMapping").GetProperty("mode").GetString().ShouldBe(mode);
        string nativeFolder = profile == "full-mtp" ? "P0Fixture.NativeTests" : "P0Fixture.NativeTests.VsTest";
        string nativeCapture = Path.Combine(fixture.Checkout, "test", "fixtures", "module", "executable", nativeFolder, "native-environment.txt");
        File.Exists(nativeCapture).ShouldBeTrue(output.ToString());
        string[] nativeEnvironment = await File.ReadAllLinesAsync(nativeCapture, TestContext.Current.CancellationToken).ConfigureAwait(true);
        nativeEnvironment[0].ShouldBe(hash);
        nativeEnvironment[1].ShouldContain("SourceMapping.targets");
        nativeEnvironment[4].ShouldContain("SourceMapping.final.targets");
        nativeEnvironment[5].ShouldBe(mode == "source" ? "Debug" : "Release");
        nativeEnvironment[6].ShouldContain("--configuration " + (mode == "source" ? "Debug" : "Release"));
        if (profile == "full-mtp")
        {
            nativeEnvironment[6].ShouldContain("--project");
        }
    }

    /// <summary>Verifies a nonexecutable manifest keeps its prerequisite diagnostic when Aspire is absent.</summary>
    /// <returns>A task for the assertion.</returns>
    [Fact]
    public async Task NonexecutableManifestReportsHxr003BeforeAspireProbeAsync()
    {
        using WorkspaceGitFixture fixture = await WorkspaceGitFixture.CreateAsync().ConfigureAwait(true);
        Directory.Delete(Path.Combine(fixture.Directory, "dependency"), recursive: true);
        string repository = CompositionTestFiles.RepositoryRoot();
        CopyFixtureTree(Path.Combine(repository, "test", "fixtures", "module"), Path.Combine(fixture.Checkout, "test", "fixtures", "module"), skipBuildFolders: true);
        File.Copy(Path.Combine(repository, "test", "fixtures", "module", "positive", "hexalith.module-manifest.v1.json"), fixture.Manifest, overwrite: true);
        CompositionEngineOptions options = new(Path.Combine(fixture.Directory, "missing-apphost.dll"), typeof(ModuleCommandApplication).Assembly.Location)
        {
            AspireCommand = Path.Combine(fixture.Directory, "missing-aspire"),
            StateDirectory = Path.Combine(fixture.Directory, "state"),
            WorkspaceRoot = Path.Combine(fixture.Directory, "workspaces"),
        };

#pragma warning disable CA2007 // Test assertions require the xUnit synchronization context.
        await using StringWriter output = new();
        await using StringWriter error = new();
#pragma warning restore CA2007
        _ = await ModuleCommandApplication.InvokeAsync(
            ["run", "--manifest", fixture.Manifest, "--mode", "source", "--output", "json"],
            output,
            error,
            TestContext.Current.CancellationToken,
            typeof(ModuleCommandApplication).Assembly.Location,
            options).ConfigureAwait(true);

        output.ToString().ShouldContain("HXR003");
        output.ToString().ShouldNotContain("HXR015");
        output.ToString().ShouldNotContain("HXW004");
        Directory.Exists(options.WorkspaceRoot).ShouldBeFalse();
    }

    /// <summary>Verifies a nonexecutable manifest in an uninitialized direct reference is classified after checkout.</summary>
    /// <param name="aspireAvailable">Whether an Aspire probe is available.</param>
    /// <returns>A task for the assertion.</returns>
    [Theory]
    [InlineData(true)]
    [InlineData(false)]
    public async Task DirectReferenceNonexecutableManifestReportsHxr003Async(bool aspireAvailable)
    {
        using WorkspaceGitFixture fixture = await WorkspaceGitFixture.CreateAsync(withDirectManifest: true).ConfigureAwait(true);
        string repository = CompositionTestFiles.RepositoryRoot();
        string dependency = Path.Combine(fixture.Directory, "dependency");
        CopyFixtureTree(Path.Combine(repository, "test", "fixtures", "module"), Path.Combine(dependency, "test", "fixtures", "module"), skipBuildFolders: true);
        File.Copy(Path.Combine(repository, "test", "fixtures", "module", "positive", "hexalith.module-manifest.v1.json"), Path.Combine(dependency, "module.json"), overwrite: true);
        _ = await WorkspaceGitFixture.RunGitAsync(dependency, "add", "module.json", "test").ConfigureAwait(true);
        _ = await WorkspaceGitFixture.RunGitAsync(dependency, "commit", "-m", "add nonexecutable manifest").ConfigureAwait(true);
        string recorded = (await WorkspaceGitFixture.RunGitAsync(dependency, "rev-parse", "HEAD").ConfigureAwait(true)).Output.Trim();
        _ = await WorkspaceGitFixture.RunGitAsync(fixture.Checkout, "update-index", "--cacheinfo", $"160000,{recorded},references/Hexalith.Dep").ConfigureAwait(true);
        string manifest = Path.Combine(fixture.Checkout, "references", "Hexalith.Dep", "module.json");
        string aspire = Path.Combine(fixture.Directory, "missing-aspire");
        if (aspireAvailable)
        {
            aspire = OperatingSystem.IsWindows()
                ? (await CompositionTestFiles.BuildPortableToolchainAsync(fixture.Directory, TestContext.Current.CancellationToken).ConfigureAwait(true)).Aspire
                : CompositionTestFiles.CreateAspire(fixture.Directory);
        }

        CompositionEngineOptions options = new(Path.Combine(fixture.Directory, "missing-apphost.dll"), typeof(ModuleCommandApplication).Assembly.Location)
        {
            AspireCommand = aspire,
            StateDirectory = Path.Combine(fixture.Directory, "state"),
            WorkspaceRoot = Path.Combine(fixture.Directory, "workspaces"),
        };

#pragma warning disable CA2007 // Test assertions require the xUnit synchronization context.
        await using StringWriter output = new();
        await using StringWriter error = new();
#pragma warning restore CA2007
        int exitCode = await ModuleCommandApplication.InvokeAsync(
            ["run", "--manifest", manifest, "--mode", "source", "--output", "json"],
            output,
            error,
            TestContext.Current.CancellationToken,
            typeof(ModuleCommandApplication).Assembly.Location,
            options).ConfigureAwait(true);

        exitCode.ShouldBe((int)ToolExitCode.PrerequisiteUnavailable);
        output.ToString().ShouldContain("HXR003");
        output.ToString().ShouldNotContain("HXR015");
        output.ToString().ShouldNotContain("HXW004");
        output.ToString().ShouldContain("Qualify the runner-owned G-6 topology before retrying.");
        using System.Text.Json.JsonDocument response = System.Text.Json.JsonDocument.Parse(output.ToString());
        System.Text.Json.JsonElement diagnostic = response.RootElement.GetProperty("diagnostics").EnumerateArray().Single(item => item.GetProperty("ruleId").GetString() == "HXR003");
        diagnostic.GetProperty("field").GetString().ShouldBe("runtime");
        diagnostic.GetProperty("message").GetString().ShouldBe("The approved descriptor ABI cannot yet be composed into a supported runtime.");
        File.Exists(manifest).ShouldBeTrue();
        Directory.Exists(options.WorkspaceRoot).ShouldBeFalse();
    }

    /// <summary>Verifies an executable direct-reference manifest reaches the Aspire probe after recorded checkout.</summary>
    /// <returns>A task for the assertion.</returns>
    [Fact]
    public async Task DirectReferenceExecutableManifestProbesAspireAfterCheckoutAsync()
    {
        using WorkspaceGitFixture fixture = await WorkspaceGitFixture.CreateAsync(withDirectManifest: true).ConfigureAwait(true);
        string dependency = Path.Combine(fixture.Directory, "dependency");
        string repository = CompositionTestFiles.RepositoryRoot();
        string executable = Path.Combine(repository, "test", "fixtures", "module", "executable", "hexalith.module-manifest.v1.json");
        File.Copy(executable, Path.Combine(dependency, "module.json"), overwrite: true);
        CopyFixtureTree(
            Path.Combine(repository, "test", "fixtures", "module", "executable", "profiles"),
            Path.Combine(dependency, "test", "fixtures", "module", "executable", "profiles"),
            skipBuildFolders: true);
        foreach (string descriptor in new[] { "P0Fixture.Orders.Descriptor", "P0Fixture.Inventory.Descriptor", "P0Fixture.Ui.Descriptor" })
        {
            string relative = Path.Combine("artifacts", "g4-fixture", "bin", descriptor, descriptor + ".dll");
            string target = Path.Combine(dependency, relative);
            _ = Directory.CreateDirectory(Path.GetDirectoryName(target)!);
            File.Copy(Path.Combine(repository, relative), target);
        }

        _ = await WorkspaceGitFixture.RunGitAsync(dependency, "add", "-f", "module.json", "test", "artifacts").ConfigureAwait(true);
        _ = await WorkspaceGitFixture.RunGitAsync(dependency, "commit", "-m", "add executable manifest").ConfigureAwait(true);
        string recorded = (await WorkspaceGitFixture.RunGitAsync(dependency, "rev-parse", "HEAD").ConfigureAwait(true)).Output.Trim();
        _ = await WorkspaceGitFixture.RunGitAsync(fixture.Checkout, "update-index", "--cacheinfo", $"160000,{recorded},references/Hexalith.Dep").ConfigureAwait(true);
        string manifest = Path.Combine(fixture.Checkout, "references", "Hexalith.Dep", "module.json");
        CompositionEngineOptions options = new(Path.Combine(fixture.Directory, "missing-apphost.dll"), typeof(ModuleCommandApplication).Assembly.Location)
        {
            AspireCommand = Path.Combine(fixture.Directory, "missing-aspire"),
            StateDirectory = Path.Combine(fixture.Directory, "state"),
            WorkspaceRoot = Path.Combine(fixture.Directory, "workspaces"),
        };

#pragma warning disable CA2007 // Test assertions require the xUnit synchronization context.
        await using StringWriter output = new();
        await using StringWriter error = new();
#pragma warning restore CA2007
        int exitCode = await ModuleCommandApplication.InvokeAsync(
            ["run", "--manifest", manifest, "--mode", "source", "--output", "json"],
            output,
            error,
            TestContext.Current.CancellationToken,
            typeof(ModuleCommandApplication).Assembly.Location,
            options).ConfigureAwait(true);

        exitCode.ShouldBe((int)ToolExitCode.PrerequisiteUnavailable, output.ToString());
        output.ToString().ShouldContain("HXR015");
        output.ToString().ShouldNotContain("HXR003");
        output.ToString().ShouldNotContain("HXD");
        File.Exists(manifest).ShouldBeTrue();
        Directory.Exists(options.WorkspaceRoot).ShouldBeFalse();
    }

    /// <summary>Verifies root usage and Aspire failures happen before direct initialization.</summary>
    /// <param name="command">The public command.</param>
    /// <param name="expectedRule">The expected early rule.</param>
    /// <returns>A task for the assertion.</returns>
    [Theory]
    [InlineData("run", "HXR015")]
    [InlineData("test", "HXC002")]
    public async Task RootManifestEarlyFailureDoesNotInitializeReferenceAsync(string command, string expectedRule)
    {
        using WorkspaceGitFixture fixture = await WorkspaceGitFixture.CreateAsync().ConfigureAwait(true);
        string repository = CompositionTestFiles.RepositoryRoot();
        CopyFixtureTree(Path.Combine(repository, "artifacts", "g4-fixture", "bin"), Path.Combine(fixture.Checkout, "artifacts", "g4-fixture", "bin"), skipBuildFolders: false);
        CopyFixtureTree(Path.Combine(repository, "test", "fixtures", "module", "executable"), Path.Combine(fixture.Checkout, "test", "fixtures", "module", "executable"), skipBuildFolders: true);
        string manifest = Path.Combine(fixture.Checkout, "test", "fixtures", "module", "executable", "hexalith.module-manifest.v1.json");
        CompositionEngineOptions options = new(Path.Combine(fixture.Directory, "missing-apphost.dll"), typeof(ModuleCommandApplication).Assembly.Location)
        {
            AspireCommand = Path.Combine(fixture.Directory, "missing-aspire"),
            StateDirectory = Path.Combine(fixture.Directory, "state"),
            WorkspaceRoot = Path.Combine(fixture.Directory, "workspaces"),
        };

#pragma warning disable CA2007 // Test assertions require the xUnit synchronization context.
        await using StringWriter output = new();
        await using StringWriter error = new();
#pragma warning restore CA2007
        string[] arguments = command == "test"
            ? [command, "--manifest", manifest, "--profile", "missing", "--output", "json"]
            : [command, "--manifest", manifest, "--output", "json"];
        int exitCode = await ModuleCommandApplication.InvokeAsync(
            arguments,
            output,
            error,
            TestContext.Current.CancellationToken,
            typeof(ModuleCommandApplication).Assembly.Location,
            options).ConfigureAwait(true);

        exitCode.ShouldBe(command == "test" ? (int)ToolExitCode.UsageOrManifest : (int)ToolExitCode.PrerequisiteUnavailable);
        output.ToString().ShouldContain(expectedRule);
        File.Exists(Path.Combine(fixture.Checkout, "references", "Hexalith.Dep", ".git")).ShouldBeFalse();
    }

    /// <summary>Verifies direct-reference usage errors take precedence over nonexecutable topology.</summary>
    /// <returns>A task for the assertion.</returns>
    [Fact]
    public async Task DirectReferenceProfileErrorPrecedesHxr003Async()
    {
        using WorkspaceGitFixture fixture = await WorkspaceGitFixture.CreateAsync(withDirectManifest: true).ConfigureAwait(true);
        string dependency = Path.Combine(fixture.Directory, "dependency");
        string repository = CompositionTestFiles.RepositoryRoot();
        CopyFixtureTree(Path.Combine(repository, "test", "fixtures", "module"), Path.Combine(dependency, "test", "fixtures", "module"), skipBuildFolders: true);
        string positive = Path.Combine(repository, "test", "fixtures", "module", "positive", "hexalith.module-manifest.v1.json");
        File.Copy(positive, Path.Combine(dependency, "module.json"), overwrite: true);
        _ = await WorkspaceGitFixture.RunGitAsync(dependency, "add", "module.json", "test").ConfigureAwait(true);
        _ = await WorkspaceGitFixture.RunGitAsync(dependency, "commit", "-m", "add nonexecutable profile manifest").ConfigureAwait(true);
        string recorded = (await WorkspaceGitFixture.RunGitAsync(dependency, "rev-parse", "HEAD").ConfigureAwait(true)).Output.Trim();
        _ = await WorkspaceGitFixture.RunGitAsync(fixture.Checkout, "update-index", "--cacheinfo", $"160000,{recorded},references/Hexalith.Dep").ConfigureAwait(true);
        string manifest = Path.Combine(fixture.Checkout, "references", "Hexalith.Dep", "module.json");
        CompositionEngineOptions options = new(Path.Combine(fixture.Directory, "missing-apphost.dll"), typeof(ModuleCommandApplication).Assembly.Location)
        {
            AspireCommand = Path.Combine(fixture.Directory, "missing-aspire"),
            StateDirectory = Path.Combine(fixture.Directory, "state"),
            WorkspaceRoot = Path.Combine(fixture.Directory, "workspaces"),
        };

#pragma warning disable CA2007 // Test assertions require the xUnit synchronization context.
        await using StringWriter output = new();
        await using StringWriter error = new();
#pragma warning restore CA2007
        int exitCode = await ModuleCommandApplication.InvokeAsync(
            ["test", "--manifest", manifest, "--profile", "missing", "--output", "json"],
            output,
            error,
            TestContext.Current.CancellationToken,
            typeof(ModuleCommandApplication).Assembly.Location,
            options).ConfigureAwait(true);

        exitCode.ShouldBe((int)ToolExitCode.UsageOrManifest);
        output.ToString().ShouldContain("HXC002");
        output.ToString().ShouldNotContain("HXR003");
        output.ToString().ShouldNotContain("HXR015");
        File.Exists(Path.Combine(fixture.Checkout, "references", "Hexalith.Dep", ".git")).ShouldBeTrue();
    }

    /// <summary>Verifies a resolver failure keeps the topology exit code at the public command boundary.</summary>
    /// <returns>A task for the assertion.</returns>
    [Fact]
    public async Task InvalidDirectDeclarationUsesTopologyExitCodeAsync()
    {
        using WorkspaceGitFixture fixture = await WorkspaceGitFixture.CreateAsync().ConfigureAwait(true);
        string repository = CompositionTestFiles.RepositoryRoot();
        CopyFixtureTree(Path.Combine(repository, "artifacts", "g4-fixture", "bin"), Path.Combine(fixture.Checkout, "artifacts", "g4-fixture", "bin"), skipBuildFolders: false);
        CopyFixtureTree(Path.Combine(repository, "test", "fixtures", "module", "executable"), Path.Combine(fixture.Checkout, "test", "fixtures", "module", "executable"), skipBuildFolders: true);
        string manifest = Path.Combine(fixture.Checkout, "test", "fixtures", "module", "executable", "hexalith.module-manifest.v1.json");
        string gitmodules = Path.Combine(fixture.Checkout, ".gitmodules");
        string declarations = await File.ReadAllTextAsync(gitmodules, TestContext.Current.CancellationToken).ConfigureAwait(true);
        await File.WriteAllTextAsync(gitmodules, declarations.Replace("path = references/Hexalith.Dep", "path = references/Hexalith.Other", StringComparison.Ordinal), TestContext.Current.CancellationToken).ConfigureAwait(true);
        string aspire = OperatingSystem.IsWindows()
            ? (await CompositionTestFiles.BuildPortableToolchainAsync(fixture.Directory, TestContext.Current.CancellationToken).ConfigureAwait(true)).Aspire
            : CompositionTestFiles.CreateAspire(fixture.Directory);
        CompositionEngineOptions options = new(Path.Combine(fixture.Directory, "missing-apphost.dll"), typeof(ModuleCommandApplication).Assembly.Location)
        {
            AspireCommand = aspire,
            StateDirectory = Path.Combine(fixture.Directory, "state"),
            WorkspaceRoot = Path.Combine(fixture.Directory, "workspaces"),
        };

#pragma warning disable CA2007 // Test assertions require the xUnit synchronization context.
        await using StringWriter output = new();
        await using StringWriter error = new();
#pragma warning restore CA2007
        int exitCode = await ModuleCommandApplication.InvokeAsync(
            ["run", "--manifest", manifest, "--mode", "source", "--output", "json"],
            output,
            error,
            TestContext.Current.CancellationToken,
            typeof(ModuleCommandApplication).Assembly.Location,
            options).ConfigureAwait(true);

        exitCode.ShouldBe((int)ToolExitCode.TopologyOrLifecycle);
        output.ToString().ShouldContain("HXW002");
        File.Exists(Path.Combine(fixture.Checkout, "references", "Hexalith.Dep", ".git")).ShouldBeFalse();
    }

    /// <summary>Verifies an absent root manifest keeps the manifest loader diagnostic without initializing references.</summary>
    /// <param name="mode">The tool-selected mode.</param>
    /// <returns>A task for the assertion.</returns>
    [Theory]
    [InlineData("source")]
    [InlineData("package")]
    public async Task MissingRootManifestReportsHxm005BeforeCheckoutAsync(string mode)
    {
        using WorkspaceGitFixture fixture = await WorkspaceGitFixture.CreateAsync().ConfigureAwait(true);
        File.Delete(fixture.Manifest);
        CompositionEngineOptions options = new(Path.Combine(fixture.Directory, "missing-apphost.dll"), typeof(ModuleCommandApplication).Assembly.Location)
        {
            AspireCommand = Path.Combine(fixture.Directory, "missing-aspire"),
            StateDirectory = Path.Combine(fixture.Directory, "state"),
            WorkspaceRoot = Path.Combine(fixture.Directory, "workspaces"),
        };

#pragma warning disable CA2007 // Test assertions require the xUnit synchronization context.
        await using StringWriter output = new();
        await using StringWriter error = new();
#pragma warning restore CA2007
        int exitCode = await ModuleCommandApplication.InvokeAsync(
            ["run", "--manifest", fixture.Manifest, "--mode", mode, "--output", "json"],
            output,
            error,
            TestContext.Current.CancellationToken,
            typeof(ModuleCommandApplication).Assembly.Location,
            options).ConfigureAwait(true);

        exitCode.ShouldBe((int)ToolExitCode.UsageOrManifest);
        output.ToString().ShouldContain("HXM005");
        output.ToString().ShouldNotContain("HXW001");
        File.Exists(Path.Combine(fixture.Checkout, "references", "Hexalith.Dep", ".git")).ShouldBeFalse();
    }

    /// <summary>Verifies an initialized direct manifest is not replaced by a command.</summary>
    /// <returns>A task for the assertion.</returns>
    [Fact]
    public async Task PublicRunPreservesInitializedDirectManifestOnGitlinkMismatchAsync()
    {
        using WorkspaceGitFixture fixture = await WorkspaceGitFixture.CreateAsync(withDirectManifest: true).ConfigureAwait(true);
        _ = await WorkspaceGitFixture.RunGitAsync(fixture.Checkout, "-c", "protocol.file.allow=always", "submodule", "update", "--init", "--", "references/Hexalith.Dep").ConfigureAwait(true);
        string direct = Path.Combine(fixture.Checkout, "references", "Hexalith.Dep");
        string directManifest = Path.Combine(direct, "module.json");
        string fixtureManifest = Path.Combine(CompositionTestFiles.RepositoryRoot(), "test", "fixtures", "module", "executable", "hexalith.module-manifest.v1.json");
        await File.WriteAllTextAsync(directManifest, await File.ReadAllTextAsync(fixtureManifest, TestContext.Current.CancellationToken).ConfigureAwait(true), TestContext.Current.CancellationToken).ConfigureAwait(true);
        string[] requiredFiles =
        [
            "artifacts/g4-fixture/bin/P0Fixture.Orders.Descriptor/P0Fixture.Orders.Descriptor.dll",
            "artifacts/g4-fixture/bin/P0Fixture.Inventory.Descriptor/P0Fixture.Inventory.Descriptor.dll",
            "artifacts/g4-fixture/bin/P0Fixture.Ui.Descriptor/P0Fixture.Ui.Descriptor.dll",
            "test/fixtures/module/executable/profiles/p0-two-module-full.fixture.json",
            "test/fixtures/module/executable/profiles/p0-two-module-full-mtp.fixture.json",
            "test/fixtures/module/executable/profiles/p0-executable-live.fixture.json",
        ];
        foreach (string required in requiredFiles)
        {
            string file = Path.Combine(direct, required);
            _ = Directory.CreateDirectory(Path.GetDirectoryName(file)!);
            await File.WriteAllTextAsync(file, "{}", TestContext.Current.CancellationToken).ConfigureAwait(true);
        }

        _ = await WorkspaceGitFixture.RunGitAsync(direct, "config", "user.name", "Workspace Test").ConfigureAwait(true);
        _ = await WorkspaceGitFixture.RunGitAsync(direct, "config", "user.email", "workspace@example.invalid").ConfigureAwait(true);
        _ = await WorkspaceGitFixture.RunGitAsync(direct, "add", "module.json", "artifacts", "test").ConfigureAwait(true);
        _ = await WorkspaceGitFixture.RunGitAsync(direct, "commit", "-m", "advance manifest").ConfigureAwait(true);
        ModuleManifestLoader.Load(directManifest).IsValid.ShouldBeTrue();
        CompositionEngineOptions options = new(Path.Combine(fixture.Directory, "missing-apphost.dll"), typeof(ModuleCommandApplication).Assembly.Location)
        {
            AspireCommand = OperatingSystem.IsWindows()
                ? (await CompositionTestFiles.BuildPortableToolchainAsync(fixture.Directory, TestContext.Current.CancellationToken).ConfigureAwait(true)).Aspire
                : CompositionTestFiles.CreateAspire(fixture.Directory),
            StateDirectory = Path.Combine(fixture.Directory, "state"),
            WorkspaceRoot = Path.Combine(fixture.Directory, "workspaces"),
        };

#pragma warning disable CA2007 // Test assertions require the xUnit synchronization context.
        await using StringWriter output = new();
        await using StringWriter error = new();
#pragma warning restore CA2007
        int exitCode = await ModuleCommandApplication.InvokeAsync(
            ["run", "--manifest", directManifest, "--mode", "source", "--output", "json"],
            output,
            error,
            TestContext.Current.CancellationToken,
            typeof(ModuleCommandApplication).Assembly.Location,
            options).ConfigureAwait(true);

        exitCode.ShouldBe((int)ToolExitCode.PrerequisiteUnavailable);
        (await File.ReadAllTextAsync(directManifest, TestContext.Current.CancellationToken).ConfigureAwait(true)).ShouldNotBe("{}");
        output.ToString().ShouldContain("HXW004");
        output.ToString().ShouldContain("Hexalith.Dep");
        using System.Text.Json.JsonDocument response = System.Text.Json.JsonDocument.Parse(output.ToString());
        response.RootElement.GetProperty("status").GetString().ShouldBe("unavailable");
        Directory.Exists(options.WorkspaceRoot).ShouldBeFalse();
    }

    /// <summary>Verifies a staged executable gitlink does not replace an initialized stale manifest.</summary>
    /// <returns>A task for the assertion.</returns>
    [Fact]
    public async Task PublicRunRejectsStaleInitializedManifestBeforeParsingAsync()
    {
        const string oldManifest = "{ malformed";
        using WorkspaceGitFixture fixture = await WorkspaceGitFixture.CreateAsync(withDirectManifest: true).ConfigureAwait(true);
        _ = await WorkspaceGitFixture.RunGitAsync(fixture.Checkout, "-c", "protocol.file.allow=always", "submodule", "update", "--init", "--", "references/Hexalith.Dep").ConfigureAwait(true);
        string direct = Path.Combine(fixture.Checkout, "references", "Hexalith.Dep");
        string directManifest = Path.Combine(direct, "module.json");
        await File.WriteAllTextAsync(directManifest, oldManifest, TestContext.Current.CancellationToken).ConfigureAwait(true);
        string fixtureRoot = Path.Combine(CompositionTestFiles.RepositoryRoot(), "test", "fixtures", "module");
        CopyFixtureTree(Path.Combine(fixtureRoot, "descriptors"), Path.Combine(direct, "test", "fixtures", "module", "descriptors"), skipBuildFolders: false);
        CopyFixtureTree(Path.Combine(fixtureRoot, "profiles"), Path.Combine(direct, "test", "fixtures", "module", "profiles"), skipBuildFolders: false);
        _ = await WorkspaceGitFixture.RunGitAsync(direct, "config", "user.name", "Workspace Test").ConfigureAwait(true);
        _ = await WorkspaceGitFixture.RunGitAsync(direct, "config", "user.email", "workspace@example.invalid").ConfigureAwait(true);
        _ = await WorkspaceGitFixture.RunGitAsync(direct, "add", "module.json", "test").ConfigureAwait(true);
        _ = await WorkspaceGitFixture.RunGitAsync(direct, "commit", "-m", "add valid persisted manifest").ConfigureAwait(true);
        string old = (await WorkspaceGitFixture.RunGitAsync(direct, "rev-parse", "HEAD").ConfigureAwait(true)).Output.Trim();
        _ = await WorkspaceGitFixture.RunGitAsync(fixture.Checkout, "add", "references/Hexalith.Dep").ConfigureAwait(true);
        string fixtureManifest = Path.Combine(CompositionTestFiles.RepositoryRoot(), "test", "fixtures", "module", "executable", "hexalith.module-manifest.v1.json");
        await File.WriteAllTextAsync(directManifest, await File.ReadAllTextAsync(fixtureManifest, TestContext.Current.CancellationToken).ConfigureAwait(true), TestContext.Current.CancellationToken).ConfigureAwait(true);
        _ = await WorkspaceGitFixture.RunGitAsync(direct, "add", "module.json").ConfigureAwait(true);
        _ = await WorkspaceGitFixture.RunGitAsync(direct, "commit", "-m", "add executable manifest").ConfigureAwait(true);
        _ = await WorkspaceGitFixture.RunGitAsync(fixture.Checkout, "add", "references/Hexalith.Dep").ConfigureAwait(true);
        _ = await WorkspaceGitFixture.RunGitAsync(direct, "checkout", old).ConfigureAwait(true);
        (await File.ReadAllTextAsync(directManifest, TestContext.Current.CancellationToken).ConfigureAwait(true)).ShouldBe(oldManifest);
        ModuleManifestLoader.Load(directManifest).IsValid.ShouldBeFalse();
        CompositionEngineOptions options = new(Path.Combine(fixture.Directory, "missing-apphost.dll"), typeof(ModuleCommandApplication).Assembly.Location)
        {
            AspireCommand = OperatingSystem.IsWindows()
                ? (await CompositionTestFiles.BuildPortableToolchainAsync(fixture.Directory, TestContext.Current.CancellationToken).ConfigureAwait(true)).Aspire
                : CompositionTestFiles.CreateAspire(fixture.Directory),
            StateDirectory = Path.Combine(fixture.Directory, "state"),
            WorkspaceRoot = Path.Combine(fixture.Directory, "workspaces"),
        };

#pragma warning disable CA2007 // Test assertions require the xUnit synchronization context.
        await using StringWriter output = new();
        await using StringWriter error = new();
#pragma warning restore CA2007
        int exitCode = await ModuleCommandApplication.InvokeAsync(
            ["run", "--manifest", directManifest, "--mode", "source", "--output", "json"],
            output,
            error,
            TestContext.Current.CancellationToken,
            typeof(ModuleCommandApplication).Assembly.Location,
            options).ConfigureAwait(true);

        exitCode.ShouldBe((int)ToolExitCode.PrerequisiteUnavailable);
        output.ToString().ShouldContain("HXW004");
        output.ToString().ShouldNotContain("HXR003");
        (await File.ReadAllTextAsync(directManifest, TestContext.Current.CancellationToken).ConfigureAwait(true)).ShouldBe(oldManifest);
        Directory.Exists(options.WorkspaceRoot).ShouldBeFalse();
    }

    /// <summary>Verifies public run initializes a direct reference before parsing an absent manifest.</summary>
    /// <param name="mode">The tool-selected workspace mode.</param>
    /// <returns>A task for the assertion.</returns>
    [Theory]
    [InlineData("source")]
    [InlineData("package")]
    public async Task PublicRunRestoresAbsentDirectManifestBeforeParsingAsync(string mode)
    {
        using WorkspaceGitFixture fixture = await WorkspaceGitFixture.CreateAsync(withDirectManifest: true).ConfigureAwait(true);
        string manifest = Path.Combine(fixture.Checkout, "references", "Hexalith.Dep", "module.json");
        File.Exists(manifest).ShouldBeFalse();
        CompositionEngineOptions options = new(Path.Combine(fixture.Directory, "missing-apphost.dll"), typeof(ModuleCommandApplication).Assembly.Location)
        {
            AspireCommand = OperatingSystem.IsWindows()
                ? (await CompositionTestFiles.BuildPortableToolchainAsync(fixture.Directory, TestContext.Current.CancellationToken).ConfigureAwait(true)).Aspire
                : CompositionTestFiles.CreateAspire(fixture.Directory),
            StateDirectory = Path.Combine(fixture.Directory, "state"),
            WorkspaceRoot = Path.Combine(fixture.Directory, "workspaces"),
        };

#pragma warning disable CA2007 // Test assertions require the xUnit synchronization context.
        await using StringWriter output = new();
        await using StringWriter error = new();
#pragma warning restore CA2007
        _ = await ModuleCommandApplication.InvokeAsync(
            ["run", "--manifest", manifest, "--mode", mode, "--output", "json"],
            output,
            error,
            TestContext.Current.CancellationToken,
            typeof(ModuleCommandApplication).Assembly.Location,
            options).ConfigureAwait(true);

        File.Exists(manifest).ShouldBeTrue();
        output.ToString().ShouldContain("HXM");
        output.ToString().ShouldNotContain("HXW");
    }

    /// <summary>Verifies descriptor assemblies in a package-only reference are rejected before child execution.</summary>
    /// <param name="kind">The declared descriptor kind.</param>
    /// <returns>A task for the assertion.</returns>
    [Theory]
    [InlineData("module")]
    [InlineData("ui")]
    public async Task PackageOriginDescriptorFailsBeforeChildAsync(string kind)
    {
        using WorkspaceGitFixture fixture = await WorkspaceGitFixture.CreateAsync().ConfigureAwait(true);
        string repository = CompositionTestFiles.RepositoryRoot();
        CopyFixtureTree(Path.Combine(repository, "artifacts", "g4-fixture", "bin"), Path.Combine(fixture.Checkout, "artifacts", "g4-fixture", "bin"), skipBuildFolders: false);
        CopyFixtureTree(Path.Combine(repository, "test", "fixtures", "module", "executable"), Path.Combine(fixture.Checkout, "test", "fixtures", "module", "executable"), skipBuildFolders: true);
        string source = Path.Combine(repository, "test", "fixtures", "module", "executable", "hexalith.module-manifest.v1.json");
        string manifest = await File.ReadAllTextAsync(source, TestContext.Current.CancellationToken).ConfigureAwait(true);
        string original = kind == "module"
            ? "artifacts/g4-fixture/bin/P0Fixture.Orders.Descriptor/P0Fixture.Orders.Descriptor.dll"
            : "artifacts/g4-fixture/bin/P0Fixture.Ui.Descriptor/P0Fixture.Ui.Descriptor.dll";
        manifest = manifest.Replace(original, "references/Hexalith.Dep/Descriptor.dll", StringComparison.Ordinal);
        await File.WriteAllTextAsync(fixture.Manifest, manifest, TestContext.Current.CancellationToken).ConfigureAwait(true);
        string descriptor = Path.Combine(fixture.Checkout, "references", "Hexalith.Dep", "Descriptor.dll");
        _ = Directory.CreateDirectory(Path.GetDirectoryName(descriptor)!);
        await File.WriteAllTextAsync(descriptor, "not a managed assembly", TestContext.Current.CancellationToken).ConfigureAwait(true);
        CompositionEngineOptions options = new(Path.Combine(fixture.Directory, "missing-apphost.dll"), typeof(ModuleCommandApplication).Assembly.Location)
        {
            AspireCommand = OperatingSystem.IsWindows()
                ? (await CompositionTestFiles.BuildPortableToolchainAsync(fixture.Directory, TestContext.Current.CancellationToken).ConfigureAwait(true)).Aspire
                : CompositionTestFiles.CreateAspire(fixture.Directory),
            StateDirectory = Path.Combine(fixture.Directory, "state"),
            WorkspaceRoot = Path.Combine(fixture.Directory, "workspaces"),
        };

#pragma warning disable CA2007 // Test assertions require the xUnit synchronization context.
        await using StringWriter output = new();
        await using StringWriter error = new();
#pragma warning restore CA2007
        int exitCode = await ModuleCommandApplication.InvokeAsync(
            ["run", "--manifest", fixture.Manifest, "--mode", "package", "--output", "json"],
            output,
            error,
            TestContext.Current.CancellationToken,
            typeof(ModuleCommandApplication).Assembly.Location,
            options).ConfigureAwait(true);

        exitCode.ShouldBe((int)ToolExitCode.TopologyOrLifecycle);
        output.ToString().ShouldContain("HXW006");
        output.ToString().ShouldContain(descriptor);
        output.ToString().ShouldNotContain("HXD002");
        Directory.Exists(options.WorkspaceRoot).ShouldBeFalse();
    }

    /// <summary>Verifies a descriptor-returned UI marker under a package-origin root is rejected before loading it.</summary>
    /// <returns>A task for the assertion.</returns>
    [Fact]
    public async Task ReturnedUiMarkerUnderPackageOriginFailsMappingGuardAsync()
    {
        using WorkspaceGitFixture fixture = await WorkspaceGitFixture.CreateAsync().ConfigureAwait(true);
        string repository = CompositionTestFiles.RepositoryRoot();
        CopyFixtureTree(Path.Combine(repository, "artifacts", "g4-fixture", "bin"), Path.Combine(fixture.Checkout, "artifacts", "g4-fixture", "bin"), skipBuildFolders: false);
        CopyFixtureTree(Path.Combine(repository, "test", "fixtures", "module", "executable"), Path.Combine(fixture.Checkout, "test", "fixtures", "module", "executable"), skipBuildFolders: true);
        string marker = Path.Combine(fixture.Checkout, "references", "Hexalith.Dep", "Marker.dll");
        _ = Directory.CreateDirectory(Path.GetDirectoryName(marker)!);
        File.Copy(Path.Combine(repository, "artifacts", "g4-fixture", "bin", "P0Fixture.Ui", "P0Fixture.Ui.dll"), marker);
        string descriptorSource = Path.Combine(repository, "test", "fixtures", "module", "executable", "P0Fixture.Orders.Descriptor", "ModuleDescriptorV1.cs");
        string descriptorProjectDirectory = Path.Combine(fixture.Directory, "modified-descriptor");
        _ = Directory.CreateDirectory(descriptorProjectDirectory);
        await File.WriteAllTextAsync(
            Path.Combine(descriptorProjectDirectory, "P0Fixture.Orders.Descriptor.csproj"),
            "<Project Sdk=\"Microsoft.NET.Sdk\"><PropertyGroup><TargetFramework>net10.0</TargetFramework></PropertyGroup></Project>",
            TestContext.Current.CancellationToken).ConfigureAwait(true);
        string source = await File.ReadAllTextAsync(descriptorSource, TestContext.Current.CancellationToken).ConfigureAwait(true);
        await File.WriteAllTextAsync(
            Path.Combine(descriptorProjectDirectory, "ModuleDescriptorV1.cs"),
            source.Replace("artifacts/g4-fixture/bin/P0Fixture.Ui/P0Fixture.Ui.dll", "references/Hexalith.Dep/Marker.dll", StringComparison.Ordinal),
            TestContext.Current.CancellationToken).ConfigureAwait(true);
        string output = Path.Combine(fixture.Checkout, "artifacts", "g4-fixture", "bin", "P0Fixture.Orders.Descriptor");
        CompositionProcessResult built = await CompositionProcess.RunAsync(
            CompositionProcess.CreateStartInfo("dotnet", ["build", Path.Combine(descriptorProjectDirectory, "P0Fixture.Orders.Descriptor.csproj"), "-v:q", "-o", output], fixture.Directory, null),
            TimeSpan.FromMinutes(2),
            TestContext.Current.CancellationToken).ConfigureAwait(true);
        built.ExitCode.ShouldBe(0, built.Output);

        string manifestPath = Path.Combine(fixture.Checkout, "test", "fixtures", "module", "executable", "hexalith.module-manifest.v1.json");
        ManifestLoadResult loaded = ModuleManifestLoader.Load(manifestPath);
        loaded.IsValid.ShouldBeTrue();
        SourceMapping mapping = new(
            WorkspaceMode.Package,
            fixture.Checkout,
            Path.GetFileName(fixture.Checkout),
            [new SourceMappingEntry(Path.GetFileName(fixture.Checkout), "source", fixture.Checkout), new SourceMappingEntry("Hexalith.Dep", "package", null)],
            true);
        ExecutableDescriptorLoadResult result = await ExecutableDescriptorLoader.LoadAsync(
            loaded.Manifest!,
            manifestPath,
            typeof(ModuleCommandApplication).Assembly.Location,
            TestContext.Current.CancellationToken,
            mapping).ConfigureAwait(true);

        result.IsValid.ShouldBeFalse();
        result.Diagnostics[0].RuleId.ShouldBe("HXW006");
        result.Diagnostics[0].Message.ShouldContain(marker);
    }

    /// <summary>Verifies a descriptor-returned module project in a package-origin root stops the engine before state creation.</summary>
    /// <returns>A task for the assertion.</returns>
    [Fact]
    public async Task DescriptorModuleProjectOutsideMappingStopsEngineAsync()
    {
        string root = CompositionTestFiles.CreateDirectory();
        try
        {
            string repository = CompositionTestFiles.RepositoryRoot();
            string manifest = CompositionTestFiles.CopyExecutableManifest(
                Path.Combine(repository, "test", "fixtures", "module", "executable", "hexalith.module-manifest.v1.json"), root);
            string foreignProject = Path.Combine(root, "references", "Hexalith.Dep", "Foreign.csproj");
            _ = Directory.CreateDirectory(Path.GetDirectoryName(foreignProject)!);
            await File.WriteAllTextAsync(foreignProject, "<Project Sdk=\"Microsoft.NET.Sdk\" />", TestContext.Current.CancellationToken).ConfigureAwait(true);
            string descriptorDirectory = Path.Combine(root, "modified-descriptor");
            _ = Directory.CreateDirectory(descriptorDirectory);
            await File.WriteAllTextAsync(
                Path.Combine(descriptorDirectory, "P0Fixture.Orders.Descriptor.csproj"),
                "<Project Sdk=\"Microsoft.NET.Sdk\"><PropertyGroup><TargetFramework>net10.0</TargetFramework></PropertyGroup></Project>",
                TestContext.Current.CancellationToken).ConfigureAwait(true);
            string source = await File.ReadAllTextAsync(Path.Combine(repository, "test", "fixtures", "module", "executable", "P0Fixture.Orders.Descriptor", "ModuleDescriptorV1.cs"), TestContext.Current.CancellationToken).ConfigureAwait(true);
            await File.WriteAllTextAsync(
                Path.Combine(descriptorDirectory, "ModuleDescriptorV1.cs"),
                source.Replace("test/fixtures/module/executable/P0Fixture.Orders/P0Fixture.Orders.csproj", "references/Hexalith.Dep/Foreign.csproj", StringComparison.Ordinal),
                TestContext.Current.CancellationToken).ConfigureAwait(true);
            string outputDirectory = Path.Combine(root, "artifacts", "g4-fixture", "bin", "P0Fixture.Orders.Descriptor");
            CompositionProcessResult built = await CompositionProcess.RunAsync(
                CompositionProcess.CreateStartInfo("dotnet", ["build", Path.Combine(descriptorDirectory, "P0Fixture.Orders.Descriptor.csproj"), "-v:q", "-o", outputDirectory], root, null),
                TimeSpan.FromMinutes(2),
                TestContext.Current.CancellationToken).ConfigureAwait(true);
            built.ExitCode.ShouldBe(0, built.Output);
            (string Aspire, string Docker, string DaprHome, string NativeDotnet)? portable = OperatingSystem.IsWindows()
                ? await CompositionTestFiles.BuildPortableToolchainAsync(root, TestContext.Current.CancellationToken).ConfigureAwait(true)
                : null;
            SourceMapping mapping = new(
                WorkspaceMode.Package,
                root,
                Path.GetFileName(root),
                [new SourceMappingEntry(Path.GetFileName(root), "source", root), new SourceMappingEntry("Hexalith.Dep", "package", null)],
                true);
            CompositionEngineOptions options = new(typeof(ModuleCommandApplication).Assembly.Location, typeof(ModuleCommandApplication).Assembly.Location)
            {
                AspireCommand = portable?.Aspire ?? CompositionTestFiles.CreateAspire(root),
                DockerCommand = portable?.Docker ?? CompositionTestFiles.CreateStubDocker(root),
                DaprHome = portable?.DaprHome ?? CompositionTestFiles.CreateDaprHome(root, CompositionToolchainPins.DaprCliVersion, CompositionToolchainPins.DaprRuntimeVersion),
                StateDirectory = Path.Combine(root, "state"),
                WorkspaceRoot = Path.Combine(root, "workspaces"),
                SourceMapping = mapping,
            };

            CompositionStartResult result = await new CompositionEngine(options).StartAsync(manifest, TestContext.Current.CancellationToken).ConfigureAwait(true);

            result.Result.Outcome.ExitCode.ShouldBe(ToolExitCode.TopologyOrLifecycle);
            result.Result.Diagnostics[0].RuleId.ShouldBe("HXW006");
            result.Result.Diagnostics[0].Message.ShouldContain(foreignProject);
            Directory.Exists(options.StateDirectory).ShouldBeFalse();
        }
        finally
        {
            CompositionTestFiles.Delete(root);
        }
    }

    /// <summary>Verifies both accepted modes advance through parsing for run and test.</summary>
    /// <param name="command">The command.</param>
    /// <param name="mode">The mode.</param>
    /// <returns>A task for the assertion.</returns>
    [Theory]
    [InlineData("run", "source")]
    [InlineData("run", "package")]
    [InlineData("test", "source")]
    [InlineData("test", "package")]
    public async Task RunAndTestAcceptSourceAndPackageModesAsync(string command, string mode)
    {
        string[] arguments = command == "test"
            ? [command, "--manifest", "missing.json", "--profile", "full", "--mode", mode, "--output", "json"]
            : [command, "--manifest", "missing.json", "--mode", mode, "--output", "json"];
        (int exitCode, string output) = await InvokeAsync(arguments).ConfigureAwait(true);

        exitCode.ShouldBe((int)ToolExitCode.UsageOrManifest);
        output.ShouldContain("HXM005");
    }

    /// <summary>Verifies an invalid mode and a down mode fail during usage parsing.</summary>
    /// <returns>A task for the assertion.</returns>
    [Fact]
    public async Task InvalidOrDownModeFailsParsingAsync()
    {
        (int invalidExit, string invalidOutput) = await InvokeAsync("run", "--manifest", "missing.json", "--mode", "other", "--output", "json").ConfigureAwait(true);
        (int downExit, string downOutput) = await InvokeAsync("down", "--manifest", "missing.json", "--mode", "package", "--output", "json").ConfigureAwait(true);

        invalidExit.ShouldBe((int)ToolExitCode.UsageOrManifest);
        invalidOutput.ShouldContain("HXC001");
        downExit.ShouldBe((int)ToolExitCode.UsageOrManifest);
        downOutput.ShouldContain("HXC001");
    }

    /// <summary>Verifies the public package option reaches Git resolution before descriptor loading.</summary>
    /// <param name="command">The public command.</param>
    /// <returns>A task for the assertion.</returns>
    [Theory]
    [InlineData("run")]
    [InlineData("test")]
    public async Task PublicPackageModeSkipsMissingDirectSourceAsync(string command)
    {
        using WorkspaceGitFixture fixture = await WorkspaceGitFixture.CreateAsync().ConfigureAwait(true);
        string manifest = Path.Combine(CompositionTestFiles.RepositoryRoot(), "test", "fixtures", "module", "executable", "hexalith.module-manifest.v1.json");
        await File.WriteAllTextAsync(fixture.Manifest, await File.ReadAllTextAsync(manifest, TestContext.Current.CancellationToken).ConfigureAwait(true), TestContext.Current.CancellationToken).ConfigureAwait(true);
        string[] requiredFiles =
        [
            "artifacts/g4-fixture/bin/P0Fixture.Orders.Descriptor/P0Fixture.Orders.Descriptor.dll",
            "artifacts/g4-fixture/bin/P0Fixture.Inventory.Descriptor/P0Fixture.Inventory.Descriptor.dll",
            "artifacts/g4-fixture/bin/P0Fixture.Ui.Descriptor/P0Fixture.Ui.Descriptor.dll",
            "test/fixtures/module/executable/profiles/p0-two-module-full.fixture.json",
            "test/fixtures/module/executable/profiles/p0-two-module-full-mtp.fixture.json",
            "test/fixtures/module/executable/profiles/p0-executable-live.fixture.json",
        ];
        foreach (string required in requiredFiles)
        {
            string path = Path.Combine(fixture.Checkout, required);
            _ = Directory.CreateDirectory(Path.GetDirectoryName(path)!);
            await File.WriteAllTextAsync(path, "{}", TestContext.Current.CancellationToken).ConfigureAwait(true);
        }

        Directory.Delete(Path.Combine(fixture.Directory, "dependency"), recursive: true);
        string aspire = OperatingSystem.IsWindows()
            ? (await CompositionTestFiles.BuildPortableToolchainAsync(fixture.Directory, TestContext.Current.CancellationToken).ConfigureAwait(true)).Aspire
            : CompositionTestFiles.CreateAspire(fixture.Directory);
        CompositionEngineOptions options = new(Path.Combine(fixture.Directory, "missing-apphost.dll"), typeof(ModuleCommandApplication).Assembly.Location)
        {
            AspireCommand = aspire,
            StateDirectory = Path.Combine(fixture.Directory, "state"),
            WorkspaceRoot = Path.Combine(fixture.Directory, "workspaces"),
        };

#pragma warning disable CA2007 // Test assertions require the xUnit synchronization context.
        await using StringWriter sourceOutput = new();
        await using StringWriter packageOutput = new();
        await using StringWriter error = new();
#pragma warning restore CA2007
        string[] sourceArguments = command == "test"
            ? [command, "--manifest", fixture.Manifest, "--profile", "full", "--mode", "source", "--output", "json"]
            : [command, "--manifest", fixture.Manifest, "--mode", "source", "--output", "json"];
        string[] packageArguments = command == "test"
            ? [command, "--manifest", fixture.Manifest, "--profile", "full", "--mode", "package", "--output", "json"]
            : [command, "--manifest", fixture.Manifest, "--mode", "package", "--output", "json"];
        _ = await ModuleCommandApplication.InvokeAsync(
            sourceArguments,
            sourceOutput,
            error,
            TestContext.Current.CancellationToken,
            typeof(ModuleCommandApplication).Assembly.Location,
            options).ConfigureAwait(true);
        _ = await ModuleCommandApplication.InvokeAsync(
            packageArguments,
            packageOutput,
            error,
            TestContext.Current.CancellationToken,
            typeof(ModuleCommandApplication).Assembly.Location,
            options).ConfigureAwait(true);

        sourceOutput.ToString().ShouldContain("HXW004");
        packageOutput.ToString().ShouldNotContain("HXW004");
        packageOutput.ToString().ShouldContain("HXD002");
        Directory.Exists(options.WorkspaceRoot).ShouldBeFalse();
    }

    private static async Task<string> PrepareDirtyPlatformExecutableAsync(WorkspaceGitFixture fixture)
    {
        _ = await WorkspaceRootResolver.ResolveAsync(fixture.Manifest, WorkspaceMode.Source, TestContext.Current.CancellationToken).ConfigureAwait(true);
        string platform = Path.Combine(fixture.Checkout, "references", "Hexalith.Platform");
        await File.WriteAllTextAsync(Path.Combine(platform, "identity-dirty.txt"), "dirty", TestContext.Current.CancellationToken).ConfigureAwait(true);
        string repository = CompositionTestFiles.RepositoryRoot();
        CopyFixtureTree(Path.Combine(repository, "artifacts", "g4-fixture", "bin"), Path.Combine(fixture.Checkout, "artifacts", "g4-fixture", "bin"), skipBuildFolders: false);
        CopyFixtureTree(Path.Combine(repository, "test", "fixtures", "module", "executable"), Path.Combine(fixture.Checkout, "test", "fixtures", "module", "executable"), skipBuildFolders: true);
        return Path.Combine(fixture.Checkout, "test", "fixtures", "module", "executable", "hexalith.module-manifest.v1.json");
    }

    private static void AssertPublicIdentityWarning(string rendered, string format, string ruleId)
    {
        if (format == "human")
        {
            rendered.ShouldContain(ruleId + " Prerequisite None");
            return;
        }

        using System.Text.Json.JsonDocument response = System.Text.Json.JsonDocument.Parse(rendered);
        System.Text.Json.JsonElement warning = response.RootElement.GetProperty("diagnostics").EnumerateArray()
            .Single(item => item.GetProperty("ruleId").GetString() == ruleId);
        warning.GetProperty("phase").GetString().ShouldBe("Prerequisite");
        warning.GetProperty("category").GetString().ShouldBe("None");
    }

    private static void CopyFixtureTree(string source, string destination, bool skipBuildFolders)
    {
        foreach (string file in Directory.EnumerateFiles(source, "*", SearchOption.AllDirectories))
        {
            string relative = Path.GetRelativePath(source, file);
            if (skipBuildFolders && relative.Split(Path.DirectorySeparatorChar).Any(part => part is "bin" or "obj"))
            {
                continue;
            }

            string target = Path.Combine(destination, relative);
            _ = Directory.CreateDirectory(Path.GetDirectoryName(target)!);
            File.Copy(file, target);
        }
    }

    private static async Task<(int ExitCode, string Output)> InvokeAsync(params string[] arguments)
    {
        StringWriter output = new();
        await using (output.ConfigureAwait(true))
        {
            StringWriter error = new();
            await using (error.ConfigureAwait(true))
            {
                int exitCode = await ModuleCommandApplication.InvokeAsync(arguments, output, error, TestContext.Current.CancellationToken).ConfigureAwait(true);
                error.ToString().ShouldBeEmpty();
                return (exitCode, output.ToString());
            }
        }
    }
}
